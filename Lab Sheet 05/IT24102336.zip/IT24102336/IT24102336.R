setwd("C:\\Users\\kavis\\OneDrive\\Desktop\\IT24102336")
getwd()
delivery_data <- read.table("Exercise - Lab 05.txt", header = TRUE)
names(delivery_data) <- "Delivery_Time"
attach(delivery_data)
delivery_hist <- hist(Delivery_Time, main = "Histogram of Delivery Times", 
                      breaks = seq(20, 70, length = 10), right = FALSE,
                      xlab = "Delivery Time (minutes)", col = "lightcoral")
delivery_freq <- delivery_hist$counts
delivery_cum <- cumsum(delivery_freq)
delivery_new <- c(0, delivery_cum[-length(delivery_cum)])
lot(delivery_breaks, delivery_new, type = "l", 
    main = "Cumulative Frequency Polygon for Delivery Times", 
    xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency", 
    ylim = c(0, max(delivery_cum)), col = "purple", lwd = 2)
points(delivery_breaks, delivery_new, pch = 16, col = "orange")



# Example data
set.seed(123)
delivery_times <- rnorm(100, mean = 30, sd = 5)
hist_result <- hist(delivery_times, plot = FALSE)
delivery_breaks <- hist_result$breaks
delivery_counts <- hist_result$counts
delivery_cum <- c(0, cumsum(delivery_counts))

# Now plot
plot(delivery_breaks, delivery_cum, type = "l",
     main = "Cumulative Frequency Polygon for Delivery Times",
     xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency",
     ylim = c(0, max(delivery_cum)), col = "purple", lwd = 2)
points(delivery_breaks, delivery_cum, pch = 16, col = "orange")