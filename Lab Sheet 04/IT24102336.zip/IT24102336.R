getwd()
setwd("C:\\Users\\it24102336\\Desktop\\IT24102336")
data4<-read.table("DATA 4.txt",header=TRUE,sep=",")
branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
head(branch_data)

str(branch_data)
sapply(branch_data,class)
summary(branch_data)

boxplot(branch_data$Sales,main="Boxplot of Sales",ylab="Sales")
png("sales_boxplot.png")
boxplot(branch_data$Sales,main="Boxplot of Sales",ylab="Sales")

five_num_advertising<-fivenum(branch_data$Advertising)
print(five_num_advertising)
summary(branch_data$Advertising)
iqr_advertising<-IQR(branch_data$Advertising)
print(iqr_advertising)


find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

outliers_years <- find_outliers(branch_data$Years)
print(outliers_years)